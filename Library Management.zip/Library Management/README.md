# Library Management System

A full-stack library management system with React frontend and Java Spring Boot backend, using MongoDB as the database.

## Features

- **Admin Dashboard**: Add/manage members and books, view analytics
- **Member Dashboard**: Browse books, borrow/return books, view personal borrowing history
- **Real-time Updates**: WebSocket integration for real-time data synchronization
- **Authentication**: Separate login for admin and members
- **Full CRUD Operations**: Create, Read, Update, Delete for all entities

## Prerequisites

- Java 17 or higher
- Maven 3.6+
- Node.js 16+ and npm
- MongoDB (running on localhost:27017)

## Setup Instructions

### 1. Start MongoDB

Make sure MongoDB is running on `localhost:27017`

```bash
# Windows (if MongoDB is installed as service, it should start automatically)
# Or start MongoDB service manually
```

### 2. Backend Setup (Spring Boot)

```bash
# Navigate to project root
cd "L:\New folder\demo"

# Build and run the Spring Boot application
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### 3. Frontend Setup (React)

Open a new terminal:

```bash
# Navigate to project root
cd "L:\New folder\demo"

# Install dependencies
npm install

# Start development server
npm run dev
```

The frontend will start on `http://localhost:3000`

## Access Credentials

### Admin Login
- URL: `http://localhost:3000/admin`
- Username: `admin`
- Password: `admin123`

### Member Login
- URL: `http://localhost:3000/login`
- Members need to be created by admin first

## API Endpoints

### Authentication
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/login` - Member login

### Members
- `GET /api/members` - Get all members
- `GET /api/members/{id}` - Get member by ID
- `POST /api/members` - Create member
- `PUT /api/members/{id}` - Update member
- `DELETE /api/members/{id}` - Delete member

### Books
- `GET /api/books` - Get all books
- `GET /api/books?search={query}` - Search books
- `GET /api/books/{id}` - Get book by ID
- `POST /api/books` - Create book
- `PUT /api/books/{id}` - Update book
- `DELETE /api/books/{id}` - Delete book

### Borrowings
- `GET /api/borrowings` - Get all borrowings
- `GET /api/borrowings/member/{memberId}` - Get member borrowings
- `POST /api/borrowings/borrow` - Borrow a book
- `POST /api/borrowings/return/{id}` - Return a book

### Analytics
- `GET /api/analytics/member/{memberId}` - Get member analytics

## Technologies Used

### Backend
- Java 17
- Spring Boot 3.1.5
- Spring Data MongoDB
- Spring WebSocket
- Maven

### Frontend
- React 18
- React Router
- Axios
- SockJS & STOMP.js (WebSocket)
- Vite

## Project Structure

```
.
├── src/
│   ├── main/
│   │   ├── java/com/library/
│   │   │   ├── config/          # Configuration classes
│   │   │   ├── controller/      # REST controllers
│   │   │   ├── model/           # Data models
│   │   │   ├── repository/      # MongoDB repositories
│   │   │   ├── service/         # Business logic
│   │   │   └── LibraryManagementApplication.java
│   │   └── resources/
│   │       └── application.properties
│   └── components/              # React components
│       ├── AdminDashboard.jsx
│       ├── MemberDashboard.jsx
│       ├── AdminLogin.jsx
│       ├── MemberLogin.jsx
│       └── ...
├── pom.xml                      # Maven configuration
├── package.json                 # Node.js dependencies
└── vite.config.js              # Vite configuration
```

## Development

### Building for Production

Backend:
```bash
mvn clean package
java -jar target/demo-1.0-SNAPSHOT.jar
```

Frontend:
```bash
npm run build
```

The built files will be in the `dist` directory.

## Notes

- The application uses in-memory authentication (no JWT tokens for simplicity)
- MongoDB database name: `library_db`
- All data persists in MongoDB
- WebSocket connection is established automatically when dashboards load


